 

export default {

    
    increase:{
        type: 'increase'  
    }
}