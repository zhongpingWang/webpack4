import { combineReducers  } from 'redux'

import Count from "./count"
import Todo from "./todo" 


export default combineReducers({
    Count,
    Todo
});